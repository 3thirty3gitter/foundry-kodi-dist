"""Kodi-native catalog paging and cached artwork color for the VOD view."""
import re
import time
from datetime import datetime
from pathlib import Path
from PIL import Image
import xbmc
import xbmcgui
from .osd import _cached_paths, dominant_color


def catalog_details(info, home):
    def text(value):
        value = str(value or "").strip()
        return "" if value.lower() in {"n/a", "none", "null"} else value
    owner = tuple(home.getProperty("foundry.omdb.owner_" + name) for name in ("label", "year", "type"))
    current = tuple(info(label) for label in ("ListItem.Label", "ListItem.Year", "ListItem.DBTYPE"))
    def fallback(field):
        return text(home.getProperty("foundry.omdb." + field)) if owner == current and owner[0] else ""
    genres = text(info("ListItem.Genre")) or fallback("genres")
    genres = " / ".join(re.split(r"\s*/\s*|\s*,\s*", genres)[:3]) if genres else ""
    studio = text(info("ListItem.Studio")) or fallback("studio")
    language = text(info("ListItem.Property(original_language)")) or text(info("ListItem.AudioLanguage")) or fallback("language")
    convert = getattr(xbmc, "convertLanguage", None)
    if language and callable(convert):
        language = convert(language.split(",")[0].strip(), getattr(xbmc, "ISO_639_1", 0)) or language
    language = language.upper() if len(language) <= 3 else language
    is_tv = info("ListItem.DBTYPE").lower() in {"tvshow", "season", "episode"}
    details = "  \u2022  ".join(p for p in ("TV Series" if is_tv else "Movie", genres, studio, language) if p)
    released = text(info("ListItem.Premiered")) or fallback("released")
    for pattern in ("%Y-%m-%d", "%d %b %Y", "%d/%m/%Y"):
        try:
            date = datetime.strptime(released, pattern)
            month = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")[date.month - 1]
            released = "%s %d, %d" % (month, date.day, date.year)
            break
        except (ValueError, TypeError):
            continue
    return {"genres": genres, "details": details, "released_label": (("Aired " if is_tv else "Released ") + released) if released else ""}


def activate_catalog():
    monitor = xbmc.Monitor()
    for _ in range(30):
        if monitor.abortRequested() or not xbmc.getCondVisibility("Window.IsActive(videos)"):
            return False
        if xbmc.getCondVisibility("Container.Content(movies) | Container.Content(tvshows) | Container.Content(seasons) | Container.Content(episodes)"):
            if not xbmc.getCondVisibility("Control.IsVisible(57)"):
                xbmc.executebuiltin("Container.SetViewMode(57)")
            return True
        if monitor.waitForAbort(.05):
            break
    return False


def page_target(current_item, total, direction, page_size=6):
    try:
        count, current = int(total), max(0, int(current_item) - 1)
    except (TypeError, ValueError):
        return None
    if count <= 0 or direction not in {"next", "previous"}:
        return None
    page = min(current, count - 1) // page_size
    target_page = page + (1 if direction == "next" else -1)
    return max(0, min((count - 1) // page_size, target_page)) * page_size


def page(direction):
    if not xbmc.getCondVisibility("Window.IsActive(videos) + Control.IsVisible(57)"):
        return False
    target = page_target(xbmc.getInfoLabel("Container(57).CurrentItem"), xbmc.getInfoLabel("Container(57).NumItems"), direction)
    if target is None:
        return False
    xbmc.executebuiltin("SetFocus(57,%d,absolute)" % target)
    return True


def prepare_artwork():
    """Use thumbnails already cached by Kodi; never fetch remote artwork here."""
    if not xbmc.getCondVisibility("Window.IsActive(videos) + Control.IsVisible(57)"):
        return
    info = xbmc.getInfoLabel
    artwork = info("ListItem.Art(fanart)") or info("ListItem.Art(poster)") or info("ListItem.Icon")
    home = xbmcgui.Window(10000)
    owner = tuple(info(label) for label in ("ListItem.Label", "ListItem.Year", "ListItem.DBTYPE"))
    details = catalog_details(info, home)
    if owner != tuple(info(label) for label in ("ListItem.Label", "ListItem.Year", "ListItem.DBTYPE")):
        return
    for name, value in details.items():
        home.setProperty("foundry.vod." + name, value)
    for name, value in zip(("owner_label", "owner_year", "owner_type"), owner):
        home.setProperty("foundry.vod." + name, value)
    if artwork == home.getProperty("foundry.vod.artwork"):
        return
    color, found = (72, 168, 240), False
    for path in _cached_paths(artwork) if artwork else ():
        try:
            if not Path(path).is_file():
                continue
            with Image.open(path) as image:
                if image.width * image.height > 40_000_000:
                    continue
                color = dominant_color(image)
                found = True
                break
        except (OSError, ValueError, Image.DecompressionBombError):
            continue
    current = info("ListItem.Art(fanart)") or info("ListItem.Art(poster)") or info("ListItem.Icon")
    if current != artwork:
        return
    home.setProperty("foundry.vod.accent", "FF%02X%02X%02X" % color)
    if found:
        home.setProperty("foundry.vod.artwork", artwork)
    else:
        home.clearProperty("foundry.vod.artwork")


class CatalogArtworkMonitor:
    """Follow item changes within the rail, not only container focus events."""
    def __init__(self, clock=time.monotonic):
        self.clock, self.item, self.changed_at, self.retry = clock, None, 0, 0

    def process_current_item(self):
        if not xbmc.getCondVisibility("Window.IsActive(videos) + Control.IsVisible(57)"):
            self.item = None
            return
        item = tuple(xbmc.getInfoLabel(label) for label in ("ListItem.Art(fanart)", "ListItem.Art(poster)", "ListItem.Label", "ListItem.Genre"))
        if item != self.item:
            self.item, self.changed_at, self.retry = item, self.clock(), 0
            home = xbmcgui.Window(10000)
            if (item[0] or item[1]) != home.getProperty("foundry.vod.artwork"):
                home.setProperty("foundry.vod.accent", "FF48A8F0")
        if self.clock() - self.changed_at >= .2 and self.clock() >= self.retry:
            prepare_artwork()
            self.retry = self.clock() + 1
