# Foundry Helper 1.3.1 candidate handoff

Updated 2026-11-09 UTC. Branch: `dev`. Intended distribution: next Foundry 1.5.0. Source is ready for parent review; this handoff does not authorize production publication.

## Implemented

- Helper version 1.3.1 adds provider-neutral, source-scoped Movies submenu context. The exact property is `Window.Property(foundry.movie_submenu_label)` on the catalog WindowXML.
- `resources/lib/modules/movie_submenu.py` defines the thirteen approved canonical labels and exact complete-label/terminal-breadcrumb matching. No URL/provider identity guesses or fuzzy aliases.
- `vod.activate_catalog` captures explicit native category/folder labels. Catalog publication requires verified movie classification. Mixed/TV/nonmedia or unrelated child contexts clear the label.
- `DirectorySource` retains its own context. Server paging carries it, Back restores the retained parent, playback reinitialization retains it, and search results are classified before the retained library context returns.
- Source item art, custom/fanart precedence in the skin, opaque URLs, profile keys, search history, optional enrichment failure isolation and user sound choices are preserved.

## Verification

Passing targeted distribution tests: movie_submenu_context (9), catalog_handoff (9), library_partial_load (6), catalog_back_navigation (8), provider_catalog (22), playback_stop_renderer diagnostics/isolation (6).

The native interface renderer now exercises three real catalog context-Play / native Stop / Back cycles, selected-item/source/file/submenu preservation, no false source message, exact parent return, and complete Kodi traceback/diagnostic capture. It uses a private profile, free RPC port, own-log/profile identity readiness and private display.

Local Ubuntu 24.04 WSL supplies Kodi 20.5. The diagnostic attempt correctly rejected the shipped skin's GUI 5.17 requirement before playback. No skin minimum was lowered. Kodi 21.3 dev CI, exact final source/extracted-package suites and all native gates are still pending at this handoff.

## Playback investigation boundary

The original device's false error after stopping playback has not been reproduced or confirmed fixed. No speculative playback behavior patch was made. Obtain the full affected-device Kodi traceback and repeat its provider/playback/Stop/Back sequence. The controlled fixture can establish regression coverage but does not prove the original device error is resolved.

The existing catalog already rehydrates a native list released by fullscreen playback, uses idempotent close requests, isolates optional metadata diagnostics and limits final Back to its original Videos path. Preserve those contracts.

## Release and ownership

Published Foundry 1.4.0 / helper 1.3.0 packages and source pins remain unchanged. Parent Jimmy coordinates final review, source commits, distribution pins, CI and approval gates. Do not commit/push another task's files or close/release another session's ownership.
