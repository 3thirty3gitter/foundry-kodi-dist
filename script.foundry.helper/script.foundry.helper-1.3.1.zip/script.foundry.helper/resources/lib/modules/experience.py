"""Apply the selected Foundry sound default once without resetting user audio settings."""
import json
import xbmc

SOUND_ADDON = "resource.uisounds.foundry.pulse"
MIGRATION = "foundry.sounds.pulse.v1"
LEGACY_MIGRATION = "foundry.sounds.default.v1"


def _rpc(method, params):
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": method, "params": params,
        })))
        return response.get("result") if isinstance(response, dict) else None
    except (ValueError, TypeError, RuntimeError):
        return None


def _complete():
    xbmc.executebuiltin("Skin.SetBool(" + MIGRATION + ")")


def configure_experience():
    if xbmc.getSkinDir() != "skin.foundry":
        return False
    if xbmc.getCondVisibility("Skin.HasSetting(" + MIGRATION + ")"):
        return False
    if not xbmc.getCondVisibility("System.HasAddon(" + SOUND_ADDON + ")"):
        return False
    result = _rpc("Settings.GetSettingValue", {"setting": "lookandfeel.soundskin"})
    if not isinstance(result, dict) or not isinstance(result.get("value"), str):
        return False
    current = result["value"]
    managed = xbmc.getCondVisibility("Skin.HasSetting(" + LEGACY_MIGRATION + ")")
    eligible = (current == "resource.uisounds.androidtv" and managed) or (
        current == "resource.uisounds.kodi" and not managed
    )
    # None, custom packs, and explicit later returns to Kodi sounds are choices.
    # Consume this one-time migration without changing those choices.
    if current == SOUND_ADDON or not eligible:
        _complete()
        return False
    result = _rpc("Settings.SetSettingValue", {
        "setting": "lookandfeel.soundskin", "value": SOUND_ADDON,
    })
    if result is not True:
        xbmc.log("[Foundry] Pulse sound default could not be applied", xbmc.LOGERROR)
        return False
    _complete()
    return True
