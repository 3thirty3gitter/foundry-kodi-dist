"""Install the approved full-frame Foundry artwork for Kodi's next launch."""
import hashlib
import os
import tempfile

import xbmcaddon
import xbmcvfs


ARTWORK_SHA256 = "a30da8f51f0828f2b11f398eab546ae2f880550b624244aff4810cf98a3971a9"


def install_startup_splash():
    """Use Kodi's writable splash override, preserving any earlier custom files.

    Kodi checks home/media/splash.jpg before splash.png. Move that override out
    of the way after installing our PNG, otherwise it would still win. Never
    modify Kodi's APK, installation directory, settings, or the approved image.
    """
    skin = xbmcaddon.Addon("skin.foundry").getAddonInfo("path")
    source = os.path.join(skin, "media", "foundry-backdrops", "foundry-loading-splash.png")
    with open(xbmcvfs.translatePath(source), "rb") as stream:
        artwork = stream.read()
    if hashlib.sha256(artwork).hexdigest() != ARTWORK_SHA256:
        raise ValueError("Foundry startup artwork failed its integrity check")

    directory = xbmcvfs.translatePath("special://home/media/")
    os.makedirs(directory, exist_ok=True)
    destination = os.path.join(directory, "splash.png")
    current = None
    if os.path.isfile(destination):
        with open(destination, "rb") as stream:
            current = stream.read()
    changed = current != artwork
    if changed:
        descriptor, temporary = tempfile.mkstemp(prefix=".foundry-splash-", dir=directory)
        try:
            with os.fdopen(descriptor, "wb") as stream:
                stream.write(artwork)
            if current is not None:
                _preserve(destination)
            os.replace(temporary, destination)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
    jpeg = os.path.join(directory, "splash.jpg")
    if os.path.isfile(jpeg):
        _preserve(jpeg)
        changed = True
    return changed


def _preserve(path):
    """Keep every prior custom splash without overwriting an earlier backup."""
    backup = path + ".before-foundry"
    number = 1
    while os.path.exists(backup):
        backup = path + ".before-foundry." + str(number)
        number += 1
    os.replace(path, backup)
