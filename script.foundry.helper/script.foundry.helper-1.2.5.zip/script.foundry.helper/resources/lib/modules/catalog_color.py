"""Read Kodi's actual texture-cache mapping, off the GUI thread."""
from pathlib import Path
import hashlib
import re
from urllib.parse import unquote
import xbmcvfs
from PIL import Image
from .catalog_source import rpc
from .osd import dominant_color


def cached_paths(artwork):
    if not artwork:return []
    decoded=unquote(artwork[8:]).rstrip('/') if artwork.startswith('image://') else artwork
    paths=[]
    # Both Windows drive paths and POSIX local paths are legitimate. No remote
    # shares or URLs are opened by PIL; remote artwork is owned/cached by Kodi.
    local=xbmcvfs.translatePath(decoded)
    if (Path(local).is_absolute() or (len(local)>2 and local[1:3] in (':\\',':/'))) and not local.startswith(('\\\\','//')):
        paths.append(local)
    for url in dict.fromkeys((artwork,decoded)):
        try:
            textures=rpc('Textures.GetTextures',{'properties':['cachedurl'],'filter':{'field':'url','operator':'is','value':url}}).get('textures',[])
        except RuntimeError:textures=[]
        for texture in textures:
            cached=texture.get('cachedurl','')
            if cached and not any(p=='..' for p in cached.replace('\\','/').split('/')):
                paths.append(xbmcvfs.translatePath('special://profile/Thumbnails/'+cached))
    return list(dict.fromkeys(paths))


def color(artwork):
    for path in cached_paths(artwork):
        try:
            with Image.open(path) as image:
                if image.width*image.height>40_000_000:continue
                rgb=dominant_color(image,fallback=(255,255,255))
                return 'FF%02X%02X%02X'%rgb
        except (OSError,ValueError,Image.DecompressionBombError):continue
    return None


def resolved(artwork):
    """Return the sampled color and a pre-tinted effect texture, off the GUI thread.

    Native Kodi21.3 list experiments render a dynamic texture path correctly,
    while the tested dynamic diffuse-color forms produce white/empty effects.
    Tint the existing glow's RGB only; never modify its alpha or media artwork.
    """
    value=color(artwork)
    if not value:return None
    if not re.fullmatch(r'FF[0-9A-F]{6}',value):return None
    template=Path(xbmcvfs.translatePath('special://skin/media/streampilot/catalog-glow.png'))
    data=template.read_bytes()
    revision=hashlib.sha256(data).hexdigest()[:12]
    folder=Path(xbmcvfs.translatePath('special://profile/addon_data/script.foundry.helper/catalog-glow'))
    folder.mkdir(parents=True,exist_ok=True)
    target=folder/('tint-%s-%s.png'%(revision,value))
    if not target.exists():
        with Image.open(template) as original:
            image=Image.new('RGBA',original.size,tuple(int(value[i:i+2],16) for i in (2,4,6))+(255,))
            image.putalpha(original.convert('RGBA').getchannel('A'))
            temporary=target.with_suffix('.tmp')
            image.save(temporary,format='PNG')
            temporary.replace(target)
        # Only this module's generated effects are eligible for eviction.
        generated=sorted(folder.glob('tint-????????????-????????.png'),key=lambda p:p.stat().st_mtime)
        for stale in generated[:-256]:
            if stale.parent==folder and stale!=target:stale.unlink(missing_ok=True)
    return value,str(target)
