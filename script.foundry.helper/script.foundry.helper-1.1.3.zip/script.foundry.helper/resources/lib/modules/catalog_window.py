"""Dedicated native Kodi catalog window: owns paging, sorting and split search.

Provider folder/playback URLs pass through unchanged. A provider without a public
search/global sort interface is explicitly scoped to its loaded directory.
"""
import json
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import time
from datetime import datetime
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
from .catalog_model import CatalogState, SORTS, clean, label
from .catalog_source import DirectorySource, rpc

BACK_ACTIONS = {9,10,92,216,247,257,275,61467}


def listitem(item):
    kind=item.get('kind','media')
    entry=xbmcgui.ListItem(label=label(item) or item.get('label',''), path=item.get('file',''), offscreen=True)
    entry.setProperty('catalog.kind',kind)
    if kind!='media':
        entry.setProperty('catalog.arrow','streampilot/catalog-%s.png'%('previous' if kind=='previous' else 'next'))
        return entry
    art=dict(item.get('art') or {})
    art['poster']=art.get('poster') or art.get('tvshow.poster') or art.get('thumb') or item.get('thumbnail') or 'DefaultMovies.png'
    entry.setArt(art)
    info={k:item[k] for k in ('title','year','plot','genre','studio','premiered','rating','mpaa','imdbnumber','playcount') if item.get(k) not in (None,'')}
    kind=item.get('type') or item.get('mediatype')
    info['mediatype']=kind if kind in {'movie','tvshow','season','episode'} else 'movie'
    if item.get('id') is not None:info['dbid']=item['id']
    entry.setInfo('video',info)
    for provider,value in (item.get('ratings') or {}).items():
        score=value.get('rating') if isinstance(value,dict) else value
        votes=value.get('votes',0) if isinstance(value,dict) else 0
        try:entry.getVideoInfoTag().setRating(float(score),int(votes),provider,provider in ('tmdb','themoviedb'))
        except (AttributeError,TypeError,ValueError):pass
    if item.get('filetype')!='directory':entry.setProperty('IsPlayable','true')
    return entry


class CatalogWindow(xbmcgui.WindowXML):
    def __init__(self,*args,source=None,section='Movies',breadcrumb='',**kwargs):
        super().__init__(*args,**kwargs)
        self.source=source
        self.section=section
        self.breadcrumb=breadcrumb if str(breadcrumb).startswith('VOD') else 'VOD  /  '+section+'  /  '+(breadcrumb or 'Your Library')
        self.state=CatalogState()
        self.library_state=None
        self.stack=[]
        self.rail=[]
        self.results=[]
        self.hero=None
        self.last_focus=(-1,-1)
        self.closed=False
        self.exit_back=False
        self.focus_pending=None
        self.initialized=False
        self.executor=ThreadPoolExecutor(max_workers=1,thread_name_prefix='foundry-catalog')
        self.pending=None
        self.request=0
        self.search=False
        self.edit_value=''
        self.changed_at=0
        self.clock=time.monotonic
        self.history_path=Path(xbmcvfs.translatePath('special://profile/addon_data/script.foundry.helper/vod-search-history.json'))
        try:self.history=json.loads(self.history_path.read_text())[:10]
        except (OSError,ValueError,TypeError):self.history=[]

    def p(self,name,value=''):
        self.setProperty('catalog.'+name,str(value))

    def focus(self,cid):
        # Properties update visibility on Kodi's next GUI frame. Retrying focus
        # avoids targeting hidden sort/search controls in the same callback.
        self.focus_pending=cid

    def onInit(self):
        if self.initialized:
            # Kodi releases WindowXML's native list when fullscreen playback
            # replaces the window. Rehydrate from the retained state on return.
            self.setContent('tvshows' if self.section=='TV Shows' else 'movies')
            xbmc.executebuiltin('Container.SetViewMode(50)')
            if not self.getListSize():self.refresh()
            return
        self.initialized=True
        self.setContent('tvshows' if self.section=='TV Shows' else 'movies')
        xbmc.executebuiltin('Container.SetViewMode(50)')
        self.p('section',self.section);self.p('breadcrumb',self.breadcrumb);self.p('sort_label','Sort By')
        self.p('accent','FF48A8F0')
        self.p('search_scope',self.section+' in your library' if self.source.scope=='library' else self.section+' in this folder')
        for i,q in enumerate(self.history):self.p('history'+str(i),q)
        self.load()

    def load(self):
        self.request+=1;self.p('loading','true');self.p('preparing','Preparing page '+str(self.state.page));self.p('message','')
        self.pending=(self.request,'load',self.executor.submit(self.source.load))

    def refresh(self,selection=None):
        self.rail=self.state.rail()
        control=self.getControl(50);self.clearList();self.addItems([listitem(i) for i in self.rail])
        offset=1 if self.rail and self.rail[0].get('kind')=='previous' else 0
        target=offset+min(self.state.selected,max(0,len(self.state.page_items())-1)) if selection is None else selection
        if self.rail:self.setCurrentListPosition(max(0,min(target,len(self.rail)-1)))
        self.p('page',self.state.page_label());self.p('sort_label','Sort By'+(' · '+dict(SORTS)[self.state.order] if self.state.order else ''))
        self.p('scope','')
        sort_text=self.getProperty('catalog.sort_label')
        self.getControl(5703).setWidth(max(160,min(740,56+len(sort_text)*13)))
        self.p('message','' if self.state.items else 'No library matches on this page. Continue to the next page or choose Your Library.')
        self.last_focus=(-1,-1)
        media=self.state.page_items()
        if media:
            self.hero=media[min(self.state.selected,len(media)-1)]
            self.update_hero(self.hero)
        else:
            self.hero=None
            for field in ('title','clearlogo','studio_logo','tmdb','imdb','rt','metacritic'):self.p(field,'')
        # Page and sort resets go to the first media item; info return does not call refresh.
        self.focus(50)

    def tick(self):
        if not self.initialized or self.closed:return
        if self.focus_pending is not None:
            target=self.focus_pending
            if self.getControl(target).isVisible():
                self.setFocusId(target)
                if self.getFocusId()==target:self.focus_pending=None
        if self.pending and self.pending[2].done():
            generation,kind,future=self.pending;self.pending=None
            if generation==self.request:
                try:
                    result=future.result()
                    if kind=='load':
                        self.state.items=result.get('items',[]);self.state.next_path=result.get('next_path','');self.state.previous_path=result.get('previous_path','')
                        self.state.server_page=int(result.get('page') or self.state.server_page)
                        self.state.server_total_pages=int(result.get('total_pages') or 0)
                        self.refresh()
                    else:self.search_results(result)
                    self.p('loading','')
                except Exception:
                    self.p('loading','');self.p('message','This source could not be loaded. Go Back and retry.');self.p('search_message','Search is unavailable. Go Back and retry.')
        if self.search:
            text=self.getControl(5801).getText()
            if text!=self.edit_value:
                self.edit_value=text;self.changed_at=self.clock();self.p('results_label','Searching…')
                self.request+=1  # invalidates any in-flight result immediately
            if self.changed_at and self.clock()-self.changed_at>=.25:
                self.changed_at=0;self.search_query(self.edit_value)
        try:
            cid=self.getFocusId()
            if cid in (50,51):
                index=self.getCurrentListPosition() if cid==50 else self.getControl(cid).getSelectedPosition()
                if (cid,index)!=self.last_focus:
                    self.last_focus=(cid,index)
                    items=self.state.page_items() if cid==51 else self.rail
                    if 0<=index<len(items) and items[index].get('kind','media')=='media':
                        self.hero=items[index]
                        if cid==50:self.state.selected=index-(1 if self.rail[0].get('kind')=='previous' else 0)
                        self.update_hero(self.hero)
        except RuntimeError:pass
        self.update_optional_ratings()

    def update_hero(self,item):
        art=item.get('art') or {};self.p('title',label(item));self.p('clearlogo',art.get('clearlogo') or art.get('tvshow.clearlogo') or '')
        self.p('fanart',art.get('fanart') or art.get('tvshow.fanart') or 'special://skin/media/foundry-home-backdrop.png')
        studio_logo=art.get('studiologo') or art.get('studio.logo') or ''
        studio_names=item.get('studio') or []
        if not studio_logo and studio_names and xbmc.getCondVisibility('System.HasAddon(resource.images.studios.white)'):
            studio_name=studio_names[0] if isinstance(studio_names,list) else studio_names.split(' / ')[0]
            studio_logo='resource://resource.images.studios.white/'+studio_name+'.png'
        self.p('studio_logo',studio_logo)
        released=clean(item.get('premiered') or item.get('year'))
        try:released=datetime.strptime(released[:10],'%Y-%m-%d').strftime('%b %d, %Y').replace(' 0',' ')
        except ValueError:pass
        self.p('released',(('Aired ' if self.section=='TV Shows' else 'Released ')+released) if released else '')
        certification=clean(item.get('mpaa'))
        for prefix in ('CA ','US '):
            if certification.startswith(prefix):certification=certification[len(prefix):]
        self.p('certification',certification)
        genre=item.get('genre') or [];genre=genre if isinstance(genre,list) else genre.split(' / ')
        studio=item.get('studio') or [];studio=' · '.join(studio) if isinstance(studio,list) else studio
        language=clean(item.get('original_language') or item.get('language')).upper()
        self.p('details','  •  '.join(v for v in ['TV Series' if self.section=='TV Shows' else 'Movie',' · '.join(genre[:3]),studio,language] if v))
        self.p('plot',clean(item.get('plot')) or 'No description available.')
        self.p('imdb','');self.p('tmdb','');self.p('rt','');self.p('metacritic','')
        for provider,score in (item.get('ratings') or {}).items():
            value=score.get('rating') if isinstance(score,dict) else score
            if value in (None,0,'0','N/A',''):continue
            name='tmdb' if provider in ('tmdb','themoviedb') else provider
            if name in ('tmdb','imdb'):self.p(name,str(value)+('/10' if name=='imdb' else ''))
        # Optional cached artwork-color calculation. No remote artwork requests here.
        self.p('accent','FF48A8F0')
        try:
            from .osd import _cached_paths,dominant_color
            from PIL import Image
            for path in _cached_paths(art.get('fanart') or art.get('poster') or ''):
                if not Path(path).is_file():continue
                with Image.open(path) as image:color=dominant_color(image)
                self.p('accent','FF%02X%02X%02X'%color);break
        except (ImportError,OSError,ValueError):pass

    def update_optional_ratings(self):
        if not self.hero:return
        home=xbmcgui.Window(10000)
        owner=tuple(home.getProperty('foundry.omdb.owner_'+n) for n in ('label','year','type'))
        expected=(self.hero.get('label') or label(self.hero),str(self.hero.get('year') or ''),self.hero.get('type') or self.hero.get('mediatype') or 'movie')
        if owner!=expected:return
        for name,field in [('imdb','imdb_rating'),('rt','rotten_tomatoes'),('metacritic','metacritic')]:
            if name=='rt' and home.getProperty('foundry.omdb.show_rotten_tomatoes')!='true':continue
            if name=='metacritic' and home.getProperty('foundry.omdb.show_metacritic')!='true':continue
            value=clean(home.getProperty('foundry.omdb.'+field))
            if value:self.p(name,value)
        try:fresh=int(self.getProperty('catalog.rt').strip('%'))>=60
        except ValueError:fresh=True
        self.p('rt_badge','streampilot/source-rating_rt_%s.png'%('fresh' if fresh else 'rotten'))

    def turn_page(self,direction):
        target=self.state.next_path if direction=='next' and self.state.page==self.state.total_pages else self.state.previous_path if direction=='previous' and self.state.page==1 else ''
        if target:
            self.stack.append((self.source,self.state));self.source=DirectorySource(target);self.state=CatalogState(server_page=self.state.server_page+(1 if direction=='next' else -1));self.load()
        else:self.state.move_page(direction);self.refresh()

    def start_search(self):
        self.library_state=self.state;self.search=True;self.p('search','true');self.p('results_label','0 results');self.p('search_message','Start typing to search your library.' if self.source.scope=='library' else 'Start typing to search loaded provider titles.')
        self.getControl(5801).setText('');self.focus(5801)

    def search_query(self,query):
        self.request+=1
        if self.source.scope=='library' and query.strip():
            self.pending=(self.request,'search',self.executor.submit(self.source.search,query,self.section=='TV Shows'))
        else:
            state=CatalogState(items=self.library_state.items,query=query);self.search_results(state.filtered() if query.strip() else [])

    def search_results(self,items):
        self.results=list(items or [])
        self.state=CatalogState(items=self.results)
        control=self.getControl(51);control.reset();control.addItems([listitem(i) for i in self.state.page_items()])
        self.p('results_label',str(len(self.results))+(' result' if len(self.results)==1 else ' results'));self.p('search_message','' if self.results else 'No matching titles.' if self.edit_value.strip() else 'Start typing to search your library.')
        self.p('page',self.state.page_label())
        self.last_focus=(-1,-1)

    def save_history(self):
        query=self.edit_value.strip()
        if not query:return
        self.history=([query]+[q for q in self.history if q.casefold()!=query.casefold()])[:10]
        self.history_path.parent.mkdir(parents=True,exist_ok=True);self.history_path.write_text(json.dumps(self.history))
        for i,q in enumerate(self.history):self.p('history'+str(i),q)

    def leave_search(self):
        self.save_history();self.request+=1;self.pending=None;self.search=False;self.p('search','');self.state=self.library_state
        # The catalog list is retained while the search panel owns focus. Do not
        # reset/repopulate it on return: its exact native scroll offset survives.
        self.p('page',self.state.page_label());self.last_focus=(-1,-1);self.focus(50)

    def onClick(self,cid):
        if cid==5701:self.back()
        elif cid==5702:self.start_search()
        elif cid==5703:self.p('sortopen','true');self.focus(5750)
        elif 5750<=cid<=5753:
            changed=self.state.set_sort(SORTS[cid-5750][0]);self.p('sortopen','')
            if changed:self.refresh()
            else:self.focus(5703)
        elif cid==5802:self.leave_search()
        elif 5830<=cid<=5839:
            index=cid-5830
            if index<len(self.history):self.getControl(5801).setText(self.history[index]);self.focus(51)
        elif cid in (5811,5812):
            self.state.move_page('previous' if cid==5811 else 'next');control=self.getControl(51);control.reset();control.addItems([listitem(i) for i in self.state.page_items()]);self.p('page',self.state.page_label());self.last_focus=(-1,-1);self.focus(51)
        elif cid in (50,51):
            index=self.getCurrentListPosition() if cid==50 else self.getControl(cid).getSelectedPosition();items=self.rail if cid==50 else self.state.page_items()
            if not 0<=index<len(items):return
            item=items[index];kind=item.get('kind','media')
            if kind in ('next','previous'):self.turn_page(kind);return
            if self.search:self.save_history()
            if item.get('filetype')=='directory':
                if self.search:self.leave_search()
                self.stack.append((self.source,self.state));self.source=DirectorySource(item['file']);self.state=CatalogState();self.load()
            else:
                # Kodi's native information dialog retains playback/resume/context behavior.
                # Returning leaves this window, list selection and scroll state intact.
                xbmcgui.Dialog().info(listitem(item))
                self.focus(cid)

    def back(self):
        if self.getProperty('catalog.sortopen'):self.p('sortopen','');self.focus(5703)
        elif self.search:
            if self.getFocusId()==51:self.focus(5801)
            else:self.leave_search()
        elif self.stack:
            self.source,self.state=self.stack.pop();self.refresh()
        else:self.exit_back=True;self.closed=True;self.close()

    def onAction(self,action):
        aid=action.getId()
        if aid in BACK_ACTIONS:self.back()
        elif self.search and aid==2 and self.getFocusId()==5801:
            if self.results:self.focus(51)
        elif self.search and aid==1 and self.getFocusId()==51 and self.getControl(51).getSelectedPosition()%3==0:
            self.focus(5801)
        elif aid==117:
            cid=self.getFocusId()
            if cid in (50,51):
                items=self.rail if cid==50 else self.state.page_items();idx=self.getCurrentListPosition() if cid==50 else self.getControl(cid).getSelectedPosition()
                if 0<=idx<len(items) and items[idx].get('kind','media')=='media':
                    item=items[idx];choice=xbmcgui.Dialog().contextmenu(['Play','Information','Open in Kodi'])
                    if choice==0:rpc('Player.Open',{'item':{'file':item.get('file','')}})
                    elif choice==1:xbmcgui.Dialog().info(listitem(item))
                    elif choice==2:
                        self.closed=True;self.close();xbmcgui.Window(10000).setProperty('foundry.catalog.handled_path',self.source.path);rpc('GUI.ActivateWindow',{'window':'videos','parameters':[self.source.path,'return']})

    def dispose(self):
        self.closed=True;self.request+=1;self.executor.shutdown(wait=False);self.close()


def open_catalog(path,section='Movies',breadcrumb='',source=None):
    if not path:return False
    addon=xbmcaddon.Addon('script.foundry.helper')
    window=CatalogWindow('script-foundry-vod.xml',addon.getAddonInfo('path'),'default','1080i',True,source=source or DirectorySource(path),section=section,breadcrumb=breadcrumb)
    home=xbmcgui.Window(10000)
    home.setProperty('foundry.catalog.active','true')
    home.setProperty('foundry.catalog.handled_path',path)
    try:
        window.show();monitor=xbmc.Monitor()
        while not window.closed and not monitor.waitForAbort(.05):window.tick()
        return True
    finally:
        back=window.exit_back
        window.dispose();del window
        home.clearProperty('foundry.catalog.active')
        if back:xbmc.executebuiltin('Action(Back)')
