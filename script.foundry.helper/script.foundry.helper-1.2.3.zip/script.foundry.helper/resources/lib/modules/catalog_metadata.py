"""Normalize optional hero metadata without locale-dependent strptime imports."""
import re
from datetime import date

from .catalog_model import clean


def names(value):
    values = value if isinstance(value, (list, tuple)) else clean(value).split(' / ')
    return [clean(v) for v in values if isinstance(v, (str, int, float)) and clean(v)]


def details(item, is_tv=False, media_kind=None):
    released = clean(item.get('premiered') or item.get('firstaired') or item.get('year'))
    match = re.match(r'^(\d{4})-(\d{2})-(\d{2})', released)
    if match:
        try:
            value = date(*(int(v) for v in match.groups()))
            months = ('Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec')
            released = '%s %d, %d' % (months[value.month-1], value.day, value.year)
        except ValueError:
            pass
    certification = clean(item.get('mpaa'))
    if certification.startswith(('CA ', 'US ')):
        certification = certification[3:]
    genre = names(item.get('genre'))[:3]
    studio = names(item.get('studio'))
    language = clean(item.get('original_language') or item.get('language')).upper()
    kind_label='TV Series' if is_tv else 'Video' if media_kind=='video' else 'Music Video' if media_kind=='musicvideo' else 'Movie'
    return {
        'released': (('Aired ' if is_tv else 'Released ') + released) if released else '',
        'certification': certification,
        'details': '  \u2022  '.join(v for v in [kind_label, ' \u00b7 '.join(genre), ' \u00b7 '.join(studio), language] if v),
        'plot': clean(item.get('plot')) or 'No description available.',
    }
