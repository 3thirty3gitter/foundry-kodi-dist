"""Identity-checked Kodi/TMDbHelper enrichment. No keys or playback URL rewrites.

TMDbHelper's documented info=details route owns its provider configuration.
Anonymous directory ratings are never relabelled IMDb or TMDb.
"""
import re
from urllib.parse import urlencode, urlsplit, parse_qs
import xbmc
from .catalog_model import clean, label
from .catalog_source import rpc, FIELDS, DIRECTORY_FIELDS
from .catalog_items import normalize, MEDIA_TYPES


def media_type(item, section='Movies'):
    kind=item.get('type') or item.get('mediatype')
    return kind if kind in MEDIA_TYPES else ('tvshow' if section=='TV Shows' else 'movie' if section=='Movies' else 'video')


def identity(item, section='Movies'):
    return (media_type(item,section),clean(item.get('file')),label(item),clean(item.get('year')))


def lookup(item, section='Movies'):
    kind=media_type(item,section)
    if kind not in ('movie','tvshow'):return None
    unique=item.get('uniqueid') or {}
    if not isinstance(unique,dict):unique={}
    params={'info':'details','tmdb_type':'tv' if kind=='tvshow' else 'movie','cacheonly':'false'}
    imdb=clean(unique.get('imdb') or item.get('imdbnumber'))
    tmdb=clean(unique.get('tmdb') or unique.get('themoviedb'))
    # Only the known TMDbHelper route's documented ID params are interpreted.
    try:path=urlsplit(clean(item.get('file')))
    except ValueError:return None
    if path.scheme=='plugin' and path.netloc=='plugin.video.themoviedb.helper':
        query=parse_qs(path.query)
        tmdb=tmdb or query.get('tmdb_id',[''])[0]
        imdb=imdb or query.get('imdb_id',[''])[0]
    if re.fullmatch(r'tt\d+',imdb):params['imdb_id']=imdb
    elif re.fullmatch(r'\d+',tmdb):params['tmdb_id']=tmdb
    elif label(item) and re.fullmatch(r'\d{4}',clean(item.get('year'))):
        params.update(query=label(item),year=clean(item.get('year')))
    else:return None  # A title alone cannot disambiguate remakes.
    return params


def matching(item,details,params):
    if not isinstance(details,dict):return False
    kind=details.get('type') or details.get('mediatype')
    if kind in ('movie','tvshow') and params.get('tmdb_type') and kind!=('tvshow' if params['tmdb_type']=='tv' else 'movie'):return False
    if 'query' in params:
        return (label(item).casefold()==label(details).casefold() and
                clean(item.get('year'))==clean(details.get('year')))
    # The upstream ID route resolves the requested identity. Reject a returned
    # conflicting IMDb ID as an additional guard if that field is available.
    unique=details.get('uniqueid') if isinstance(details.get('uniqueid'),dict) else {}
    returned_imdb=details.get('imdbnumber') or unique.get('imdb')
    returned_tmdb=unique.get('tmdb') or unique.get('themoviedb')
    return not ((params.get('imdb_id') and returned_imdb and params['imdb_id']!=str(returned_imdb)) or
                (params.get('tmdb_id') and returned_tmdb and params['tmdb_id']!=str(returned_tmdb)))


def merge(base,extra,tmdb=False):
    base=normalize(base) or {}
    extra=normalize(extra) or {}
    result=dict(base)
    # Provider identity/file/filetype/dbid never come from the metadata endpoint.
    for field in ('plot','genre','studio','premiered','year','mpaa','imdbnumber','original_language','firstaired','showtitle','season','episode'):
        if extra.get(field) not in (None,'',[],{}):result[field]=extra[field]
    result['uniqueid']=dict(base.get('uniqueid') or {});result['uniqueid'].update(extra.get('uniqueid') or {})
    art=dict(base.get('art') or {})
    for name,value in (extra.get('art') or {}).items():
        if value:art[name]=value
    result['art']=art
    ratings=dict(base.get('ratings') or {})
    ratings.update(extra.get('ratings') or {})
    # This singular rating is known TMDb only because the upstream documented
    # endpoint defines it as TMDb average; generic Files ratings remain unknown.
    if tmdb and extra.get('rating'):ratings['tmdb']={'rating':extra['rating']}
    result['ratings']=ratings
    return normalize(result)


def enrich_with_status(item,section='Movies',native_library=False):
    result=normalize(item) or {};item=result;kind=media_type(item,section)
    dbid=item.get(kind+'id') or item.get('id')
    if native_library and kind in ('movie','tvshow','season','episode') and type(dbid) is int and dbid>0:
        method='VideoLibrary.Get'+{'movie':'Movie','tvshow':'TVShow','season':'Season','episode':'Episode'}[kind]+'Details'
        properties=FIELDS+['uniqueid']
        if kind=='season':properties=['title','season','showtitle','playcount','episode','fanart','thumbnail','tvshowid','art']
        elif kind=='episode':properties=['title','plot','rating','firstaired','playcount','season','episode','showtitle','fanart','thumbnail','tvshowid','uniqueid','art','ratings','genre','studio']
        key=kind+'details'
        try:result=merge(result,rpc(method,{kind+'id':dbid,'properties':properties}).get(key,{}))
        except RuntimeError:pass  # A stale Kodi DB ID must not break the rail.
    # The direct provider facade is shared with Home/widgets, dialogs and OSD.
    # Keep the existing TMDbHelper route only as a fallback without a direct key.
    from .metadata import service, settings
    direct=settings()
    params=lookup(result,section) if not direct.get('tmdb') else None
    if params and xbmc.getCondVisibility('System.HasAddon(plugin.video.themoviedb.helper)'):
        try:
            data=rpc('Files.GetDirectory',{'directory':'plugin://plugin.video.themoviedb.helper/?'+urlencode(params),'media':'video','properties':DIRECTORY_FIELDS}).get('files',[])
            if len(data)==1 and matching(result,data[0],params):result=merge(result,data[0],tmdb=True)
        except RuntimeError:pass
    return service().enrich(result,section)


def enrich(item,section='Movies',native_library=False):
    return enrich_with_status(item,section,native_library)[0]
