"""Read Kodi's actual texture-cache mapping, off the GUI thread."""
from pathlib import Path
from urllib.parse import unquote
import xbmcvfs
from PIL import Image
from .catalog_source import rpc
from .osd import dominant_color


def color(artwork):
    if not artwork:return None
    decoded=unquote(artwork[8:]).rstrip('/') if artwork.startswith('image://') else artwork
    paths=[]
    # Both Windows drive paths and POSIX local paths are legitimate. No remote
    # shares or URLs are opened by PIL; remote artwork is owned/cached by Kodi.
    local=xbmcvfs.translatePath(decoded)
    if (Path(local).is_absolute() or (len(local)>2 and local[1:3] in (':\\',':/'))) and not local.startswith(('\\\\','//')):
        paths.append(local)
    for url in dict.fromkeys((artwork,decoded)):
        try:
            textures=rpc('Textures.GetTextures',{'properties':['cachedurl'],'filter':{'field':'url','operator':'is','value':url}}).get('textures',[])
        except RuntimeError:textures=[]
        for texture in textures:
            cached=texture.get('cachedurl','')
            if cached and not any(p=='..' for p in cached.replace('\\','/').split('/')):
                paths.append(xbmcvfs.translatePath('special://profile/Thumbnails/'+cached))
    for path in paths:
        try:
            with Image.open(path) as image:
                if image.width*image.height>40_000_000:continue
                rgb=dominant_color(image,fallback=(255,255,255))
                return 'FF%02X%02X%02X'%rgb
        except (OSError,ValueError,Image.DecompressionBombError):continue
    return None
