"""Merge owner-requested File Manager bookmarks; never install repository code."""
import json
from pathlib import Path
import xml.etree.ElementTree as ET


def merge_sources(data, entries):
    root = ET.fromstring(data) if data.strip() else ET.Element('sources')
    if root.tag != 'sources':
        raise ValueError('Unexpected sources document')
    files = root.find('files')
    if files is None:
        files = ET.SubElement(root, 'files')
    existing = {p.text.rstrip('/') for p in files.findall('source/path') if p.text}
    changed = False
    for entry in entries:
        if entry['url'].rstrip('/') in existing:
            continue
        source = ET.SubElement(files, 'source')
        ET.SubElement(source, 'name').text = entry['name']
        ET.SubElement(source, 'path', pathversion='1').text = entry['url']
        ET.SubElement(source, 'allowsharing').text = 'true'
        existing.add(entry['url'].rstrip('/'))
        changed = True
    return ET.tostring(root, encoding='unicode'), changed


def ensure_file_sources():
    import xbmc
    import xbmcvfs
    if xbmc.getSkinDir() != 'skin.foundry':
        return False
    entries = json.loads((Path(__file__).resolve().parents[2] / 'file-sources.json').read_text())
    target = Path(xbmcvfs.translatePath('special://profile/sources.xml'))
    try:
        data = target.read_text(encoding='utf-8') if target.exists() else ''
        merged, changed = merge_sources(data, entries)
        if changed:
            target.parent.mkdir(parents=True, exist_ok=True)
            # Preserve the prior valid document before an atomic local replacement.
            if data and not target.with_suffix('.xml.foundry-backup').exists():
                target.with_suffix('.xml.foundry-backup').write_text(data, encoding='utf-8')
            temporary = target.with_suffix('.xml.foundry-tmp')
            temporary.write_text(merged, encoding='utf-8')
            temporary.replace(target)
        return True
    except (OSError, ValueError, ET.ParseError):
        xbmc.log('[Foundry] File sources could not be merged; existing sources preserved.', xbmc.LOGWARNING)
        return False
