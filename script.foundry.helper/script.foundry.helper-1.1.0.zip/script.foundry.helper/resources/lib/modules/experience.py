"""Apply Foundry defaults once per profile, after native dependencies install."""
import json
import xbmc


def configure_experience():
    if xbmc.getSkinDir() != "skin.foundry":
        return False
    if xbmc.getCondVisibility("Skin.HasSetting(foundry.sounds.default.v1)"):
        return False
    if not xbmc.getCondVisibility("System.HasAddon(resource.uisounds.androidtv)"):
        return False
    response = json.loads(xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": "Settings.SetSettingValue",
        "params": {"setting": "lookandfeel.soundskin", "value": "resource.uisounds.androidtv"},
    })))
    if response.get("result") is not True:
        xbmc.log("[Foundry] Android TV sound default could not be applied: %s" % response, xbmc.LOGERROR)
        return False
    xbmc.executebuiltin("Skin.SetBool(foundry.sounds.default.v1)")
    return True
