# -*- coding: utf-8 -*-
"""
Foundry Helper - repository installer.
Installs Kodi add-on repositories from their official ZIP URLs.
Carried over from the Foundry project-1 wizard repo list.

Patterns proven on Android TV (see brain memory learnings 2026-08):
- Downloads use Kodi's native network stack (xbmcvfs.copy), never urllib
- Zip install = extractall() into special://home/addons + UpdateLocalAddons()
  (the Kodi 21.3 InstallFromZip builtin ignores its path parameter)
"""

import os
import zipfile
import json
import uuid
import stat
import xml.etree.ElementTree as ET
import xbmc
import xbmcgui
import xbmcvfs

ADDONS_DIR = xbmcvfs.translatePath("special://home/addons")
CACHE_DIR = os.path.join(
    xbmcvfs.translatePath("special://profile/addon_data/script.foundry.helper"),
    "repo_cache",
)

REPOS = [
    {
        "name": "Rector Stuff Repository",
        "zip_url": "https://github.com/rmrector/repository.rector.stuff/raw/python2/latest/repository.rector.stuff-latest.zip",
        "addon_id": "repository.rector.stuff",
        "provides": "Artwork Dump",
    },
    {
        "name": "The Crew Repository",
        "zip_url": "https://team-crew.github.io/repository.thecrew-0.3.8.zip",
        "addon_id": "repository.thecrew",
        "provides": "The Crew",
    },
    {
        "name": "Umbrella Repository",
        "zip_url": "https://umbrellaplug.github.io/repository.umbrella-2.2.6.zip",
        "addon_id": "repository.umbrella",
        "provides": "Umbrella",
    },
    {
        "name": "Seren Repository (NixGates)",
        "zip_url": "https://nixgates.github.io/packages/repository.nixgates-2.2.0.zip",
        "addon_id": "repository.nixgates",
        "provides": "Seren",
    },
    {
        "name": "Gaia Repository",
        "zip_url": "https://repo.gaiakodi.com/repository.gaia.core.zip",
        "addon_id": "repository.gaia",
        "provides": "Gaia",
    },
    {
        "name": "Jacktook Repository",
        "zip_url": "https://sam-max.github.io/repository.jacktook/repository.jacktook-0.0.5.zip",
        "addon_id": "repository.jacktook",
        "provides": "Jacktook",
    },
    {
        "name": "Slyguy Repository",
        "zip_url": "https://raw.githubusercontent.com/matthuisman/slyguy.addons/master/repository.slyguy.zip",
        "addon_id": "repository.slyguy",
        "provides": "YouTube, IPTV Merge",
    },
    {
        "name": "Marcelveldt Beta Repository",
        "zip_url": "https://raw.githubusercontent.com/kodi-community-addons/repository.marcelveldt/master/repository.marcelveldt-1.0.3.zip",
        "addon_id": "repository.marcelveldt",
        "provides": "Metadata Utils, Skin Helper Service",
    },
    {
        "name": "Jurialmunkey Alpha Repository",
        "zip_url": "https://raw.githubusercontent.com/jurialmunkey/repository.jurialmunkey/master/repository.jurialmunkey-3.4.zip",
        "addon_id": "repository.jurialmunkey",
        "provides": "Jurialmunkey add-ons",
    },
    {
        "name": "Gade Repository",
        "zip_url": "https://raw.githubusercontent.com/gade01/repository.gade/master/nexus/repository.gade/repository.gade-2.2.0.zip",
        "addon_id": "repository.gade",
        "provides": "Gade add-ons",
    },
    {
        "name": "Bossanova808 Repository",
        "zip_url": "https://raw.githubusercontent.com/bossanova808/repository.bossanova808/main/repository-downloads/repository.bossanova808/repository.bossanova808-0.2.7.zip",
        "addon_id": "repository.bossanova808",
        "provides": "Bossanova808 add-ons",
    },
    {
        "name": "CocoScrapers Repository",
        "zip_url": "https://cocojoe2411.github.io/repository.cocoscrapers-1.0.1.zip",
        "addon_id": "repository.cocoscrapers",
        "provides": "CocoScrapers Module",
    },
]


def _has_addon(addon_id):
    try:
        result = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "method": "Addons.GetAddonDetails",
            "params": {"addonid": addon_id, "properties": ["enabled"]}, "id": 1
        })))
        return result.get("result", {}).get("addon", {}).get("addonid") == addon_id
    except Exception:
        return False


def _download_repo_zip(repo):
    if not xbmcvfs.exists(os.path.dirname(CACHE_DIR)):
        xbmcvfs.mkdirs(os.path.dirname(CACHE_DIR))
    xbmcvfs.mkdirs(CACHE_DIR)
    # Unique-per-run target prevents stale cached zips being reused
    target = os.path.join(CACHE_DIR, repo["addon_id"] + "-" + uuid.uuid4().hex + ".zip")
    ok = xbmcvfs.copy(repo["zip_url"], target)
    if not ok or not xbmcvfs.exists(target):
        return None
    return target


def _extract_to_addons(zip_path, addon_id):
    with zipfile.ZipFile(zip_path) as zf:
        for entry in zf.infolist():
            parts = entry.filename.replace("\\", "/").split("/")
            if (parts[0] != addon_id or ".." in parts or
                    stat.S_ISLNK(entry.external_attr >> 16)):
                raise ValueError("Repository ZIP contains an unsafe path")
        manifest = ET.fromstring(zf.read(addon_id + "/addon.xml"))
        if manifest.get("id") != addon_id:
            raise ValueError("Repository ZIP addon ID does not match")
        zf.extractall(ADDONS_DIR)
    return True


def install_repo(repo):
    zip_path = _download_repo_zip(repo)
    if not zip_path:
        return False
    try:
        _extract_to_addons(zip_path, repo["addon_id"])
    except Exception as e:
        xbmc.log("[Foundry Helper] Repo extract failed %s: %s" % (repo["name"], str(e)), level=xbmc.LOGERROR)
        return False
    finally:
        try:
            xbmcvfs.delete(zip_path)
        except Exception:
            pass
    return True


def show_repos():
    """Multiselect repo picker. Installs chosen repos, then refreshes the addon DB."""
    dialog = xbmcgui.Dialog()
    labels = []
    for repo in REPOS:
        state = "[COLOR limegreen]installed[/COLOR]" if _has_addon(repo["addon_id"]) else "[COLOR gray]not installed[/COLOR]"
        labels.append("%s  -  %s  (%s)" % (repo["name"], repo["provides"], state))

    preselect = []
    picked = dialog.multiselect("Foundry - Choose Repositories to Install", labels, preselect=preselect)
    # NOTE (Android TV): multiselect OK lives in the right panel - DPAD to it; BACK cancels (None)
    if picked is None:
        return
    if not picked:
        return

    progress = xbmcgui.DialogProgress()
    progress.create("Foundry Repositories", "Working...")
    total = len(picked)
    failed = []
    for idx, i in enumerate(picked):
        repo = REPOS[i]
        pct = int((idx / float(total)) * 100)
        progress.update(pct, "Installing %s..." % repo["name"])
        if progress.iscanceled():
            break
        if not install_repo(repo):
            failed.append(repo["name"])
    # Registration is async: UpdateLocalAddons triggers Kodi's DB scan.
    # Do not poll Addon(id) - skins/repos can take 15-20s to register.
    xbmc.executebuiltin("UpdateLocalAddons")
    progress.update(100, "Done")
    progress.close()

    if failed:
        dialog.ok(
            "Foundry Repositories",
            "Installed with %d failure(s):[CR][CR]%s[CR][CR]Check the Kodi log for details."
            % (len(failed), "[CR]".join(failed)),
        )
    else:
        dialog.notification(
            "Foundry Repositories",
            "Repositories installed. Add-ons become available shortly.",
            xbmcgui.NOTIFICATION_INFO,
            5000,
        )
