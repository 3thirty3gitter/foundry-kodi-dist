import os
import urllib.parse
import urllib.request

import xbmc
import xbmcgui
import xbmcvfs


URL = 'https://github.com/3thirty3gitter/foundry-kodi-dist/releases/download/foundry-shield-v0.2.0/f.zip'
PACKAGE_NAME = 'foundry-wizard-turnkey.zip'


def log(message):
    xbmc.log(f'[Foundry Bootstrap] {message}', xbmc.LOGINFO)


def file_uri(path):
    normalized = path.replace('\\', '/')
    if normalized.startswith('/'):
        return 'file://' + urllib.parse.quote(normalized)
    return 'file:///' + urllib.parse.quote(normalized)


def main():
    dialog = xbmcgui.Dialog()
    if not dialog.yesno('Foundry Installer', 'Download and install Foundry Wizard now?'):
        return

    packages = xbmcvfs.translatePath('special://home/addons/packages')
    if not xbmcvfs.exists(packages):
        xbmcvfs.mkdirs(packages)
    destination = os.path.join(packages, PACKAGE_NAME)

    progress = xbmcgui.DialogProgress()
    progress.create('Foundry Installer', 'Downloading Foundry Wizard...')
    try:
        urllib.request.urlretrieve(URL, destination)
        progress.update(80, 'Installing Foundry Wizard...')
        xbmc.executebuiltin('SetSetting(addons.unknownsources, true)')
        xbmc.sleep(500)
        xbmc.executebuiltin(f'InstallFromZip({file_uri(destination)})')
        xbmc.sleep(3000)
        progress.close()
        dialog.ok('Foundry Installer', 'Foundry Wizard install started.[CR][CR]Open Program add-ons and launch Foundry Wizard to finish setup.')
    except Exception as exc:
        progress.close()
        log(f'Install failed: {exc}')
        dialog.ok('Foundry Installer', f'Install failed.[CR][CR]{exc}')


if __name__ == '__main__':
    main()
