"""
Foundry Build — Kodi skin installer
Downloads and installs the Foundry skin from a short distribution URL.
Uses Kodi's native network stack (xbmcvfs) to avoid SSL issues on Android TV.
"""

import os
import zipfile
import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')

KODI_ADDONS = xbmcvfs.translatePath('special://home/addons')
KODI_USERDATA = xbmcvfs.translatePath('special://userdata')

# Direct GitHub archive URL for dev branch (serves ZIP directly, works on Android TV)
SKIN_ZIP_URL = 'https://github.com/3thirty3gitter/skin.foundry/archive/refs/heads/dev.zip'
SKIN_ID = 'skin.foundry'


def log(msg):
    xbmc.log(f'[{ADDON_NAME}] {msg}', level=xbmc.LOGINFO)


def notify(title, message, duration_ms=5000):
    xbmcgui.Dialog().notification(title, message, xbmcgui.NOTIFICATION_INFO, duration_ms)


def download_file(src, dst, progress=None, start_pct=0, end_pct=100):
    """Copy src URL to dst using Kodi's native network stack (Android-safe)."""
    chunk_size = 64 * 1024
    total_bytes = 0

    src_file = xbmcvfs.File(src, 'rb')
    try:
        dst_file = xbmcvfs.File(dst, 'wb')
        try:
            while True:
                chunk = src_file.read(chunk_size)
                if not chunk:
                    break
                dst_file.write(chunk)
                total_bytes += len(chunk)
                if progress and (total_bytes % (chunk_size * 20) == 0):
                    pct = start_pct + int((end_pct - start_pct) * 0.5)
                    progress.update(pct)
        finally:
            dst_file.close()
    finally:
        src_file.close()

    return total_bytes


def install_skin_from_zip(zip_path):
    """Extract a skin ZIP to addons/, rewriting skin.foundry-main -> skin.foundry."""
    if not xbmcvfs.exists(zip_path):
        raise FileNotFoundError(f'Skin ZIP not found: {zip_path}')

    temp_root = os.path.join(KODI_ADDONS, 'temp.foundry.install')
    if xbmcvfs.exists(temp_root):
        delete_tree(temp_root)
    xbmcvfs.mkdirs(temp_root)

    try:
        local_zip = xbmcvfs.translatePath(zip_path)
        with zipfile.ZipFile(local_zip, 'r') as zf:
            top_dirs = set()
            for info in zf.infolist():
                parts = info.filename.split('/')
                if parts:
                    top_dirs.add(parts[0])

            if len(top_dirs) != 1:
                raise ValueError(f'Skin ZIP must contain exactly one top-level folder, found: {top_dirs}')

            raw_folder = top_dirs.pop()
            log(f'Rewriting top folder {raw_folder} -> {SKIN_ID}')

            for info in zf.infolist():
                if info.filename.startswith(raw_folder + '/'):
                    new_name = SKIN_ID + info.filename[len(raw_folder):]
                else:
                    new_name = info.filename

                if not new_name or new_name.endswith('/'):
                    continue

                dest = os.path.join(temp_root, new_name.replace('/', os.sep))
                xbmcvfs.mkdirs(os.path.dirname(dest))

                with zf.open(info) as src, xbmcvfs.File(dest, 'wb') as dst:
                    while True:
                        data = src.read(64 * 1024)
                        if not data:
                            break
                        dst.write(data)

        final_path = os.path.join(KODI_ADDONS, SKIN_ID)
        if xbmcvfs.exists(final_path):
            delete_tree(final_path)
        xbmcvfs.rename(temp_root, final_path)
        log(f'Skin installed to {final_path}')
        return True

    except Exception as e:
        delete_tree(temp_root)
        raise e


def delete_tree(path):
    """Recursively delete a folder via xbmcvfs."""
    if not xbmcvfs.exists(path):
        return
    dirs, files = xbmcvfs.listdir(path)
    for f in files:
        xbmcvfs.delete(os.path.join(path, f))
    for d in dirs:
        delete_tree(os.path.join(path, d))
    xbmcvfs.rmdir(path)


def clear_texture_cache():
    """Delete Textures13.db and trigger Kodi cache clear."""
    db = os.path.join(KODI_USERDATA, 'Database', 'Textures13.db')
    if xbmcvfs.exists(db):
        xbmcvfs.delete(db)
    xbmc.executebuiltin('CleanTextureCache')


def apply_skin(skin_id):
    """Tell Kodi to load the skin and reset skin settings."""
    xbmc.executebuiltin(f'LoadSkin({skin_id})')
    xbmc.sleep(1000)
    xbmc.executebuiltin('Skin.Reset()')


def main():
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(
        'Foundry Build',
        'Install the Foundry skin now? This will download and apply skin.foundry.',
        nolabel='Cancel',
        yeslabel='Install'
    ):
        log('User cancelled installation')
        return

    progress = xbmcgui.DialogProgress()
    progress.create('Foundry Build', 'Downloading skin...')

    try:
        zip_path = xbmcvfs.translatePath('special://home/userdata/addon_data/script.program.foundry-build/temp/skin.zip')
        if xbmcvfs.exists(zip_path):
            xbmcvfs.delete(zip_path)
        xbmcvfs.mkdirs(os.path.dirname(zip_path))

        progress.update(10, 'Downloading skin...')
        download_file(SKIN_ZIP_URL, zip_path, progress, 10, 80)

        progress.update(50, 'Installing skin...')
        install_skin_from_zip(zip_path)

        progress.update(90, 'Clearing cache...')
        clear_texture_cache()

        progress.update(95, 'Applying skin...')
        apply_skin(SKIN_ID)

        progress.update(100, 'Foundry skin applied!')
        xbmc.sleep(2000)
        progress.close()

        notify('Foundry Installed', 'Skin applied. Press Escape twice to fully reload.', 8000)
        log('Foundry Build setup complete')

    except Exception as e:
        progress.close()
        notify('Foundry Install Failed', str(e), 10000)
        log(f'Install failed: {e}')
        raise

    finally:
        try:
            if xbmcvfs.exists(zip_path):
                xbmcvfs.delete(zip_path)
        except Exception:
            pass


if __name__ == '__main__':
    main()