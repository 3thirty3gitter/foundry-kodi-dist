# Media pack selection and complete Pure Marks candidate,2026-11-15

User-approved105-path scope:31 sourced marks and74 original technical glyphs. Not all official brand logos. Adds persisted Media icon pack selection for original Foundry and Slate; missing/disabled/invalid assets preserve builtin icons. Dark-background marks, with pixel-preserving alpha-trimmed audio variants and conditional160px audio layout; default builtin layout unchanged. No network/account access or automatic pack selection.

Candidate versions: Foundry/Build/Bootstrap1.5.6,Helper1.3.7,Slate0.1.5,SlateHelper0.1.2,PureMarks0.1.0. Previous releases immutable. Full final packaged/native validation and public publication remain pending. Earlier isolated selector/audio/art native tests passed; they do not substitute for final release gates. Physical Shield/PVR and all live codecs remain unverified.

---

## Pending 1.5.5 provider contract correction

Narrow FENskeleton action-style playback route added after user identified the provider. Exact plugin URL preserved; Info Play and catalog context Play use its action contract rather than an unresolved Player.Open request. Generic resolver providers unchanged. No error dialog suppression. Native fixture validation and physical Shield confirmation remain pending; not published.

# Foundry 1.5.5 original skin candidate

Original metallic Settings icons replace framed tiles; dynamic installed video-source selection routes unknown sources honestly to their own UI. Visible Foundry naming replaces stray Nimbus headings/summaries while legal attribution and internal IDs remain. Requires helper 1.3.6.

Local development integration only. Native UI/QR validation and packaged tests pending in distribution. No publish or physical Shield fix claim. Source search11tests and fallback6tests pass.

---

# Skin 1.5.4: ten additional Movies categories, 2026-11-12

Local development candidate only. Added exact-label Genres, Providers, Languages, Years, Decades, Certifications, Because You Watched..., Watched, Recently Watched and In Progress routing. Ten new metallic icon/title wallpapers retain the exact approved Trending background outside their right-side foregrounds. Original 45 approved frames, old provenance, Home geometry, custom-background and selected-title fanart precedence remain unchanged. Owner explicitly approved deterministic composition.

Source and packaged/native checks are pending; final results are in the distribution handoff. No dev push, production publication, physical phone or Shield verification is claimed. Work is isolated under Documents/Codex/foundry-category-wallpapers-20261112/apps.

---

# Foundry skin 1.5.3 local candidate, 2026-11-11

Integrates the approved full45 wallpaper redesign and repaired full-size native keyboard with QR slide/Cancel return. Wallpaper owner verification and final combined source, extracted-package and native gates are recorded by the distribution handoff.

Unpublished local dev candidate only. No push, production merge, release or published artifact changes authorized. Physical phone/Wi-Fi and Shield remain unverified. Final combined validation is pending. Working tree: C:/Users/TrentTimmerman/Documents/Codex/foundry-phone-fix-20261111/apps.

---

# Foundry skin 1.5.2 local candidate, 2026-11-11

Movies category wallpapers no longer have legacy fanart composited above them. Pending directory adoption and first catalog paint retain wallpaper without showing the intermediate library layout. Studio-logo aliases and native keyboard Phone entry are integrated. Original artwork, custom backgrounds, fanart priority, navigation and empty native roots are preserved.

Local dev candidate only. No production publication or push authorized. Source integration passed 722 Linux tests before versioning; final versioned source/extracted and native release gates are pending. The distribution handoff is authoritative for final validation. Real phone browser/Wi-Fi and Shield remain unverified. Source checkouts are under C:/Users/TrentTimmerman/Documents/Codex/foundry-wallpaper-20261111/apps.

---
# Foundry 1.5.1 navigation repair candidate, 2026-11-11

Development work only; unpublished. Source checkout: C:/Users/TrentTimmerman/Documents/Codex/foundry-navigation-20261111/apps/skin.foundry-nimbus. Own canonical claim: Codex-repair-foundry-skin-20261111.

The Home Add-ons launcher no longer includes its opaque left MenuContentPanel. Shared search panels, controls, focus and geometry remain unchanged. Native Videos content remains visible while Foundry requests provider metadata, with loading feedback instead of a forced black frame. Helper 1.3.2 is required for persistent widget recovery and stale-navigation guards.

Focused contracts pass. Final source/extracted/native candidate validation is pending; consult the distribution handoff for current results. No Shield/provider latency or native visual-success claim is made.

Next steps:
1. Finish 1.5.1 source/extracted tests and all five native Kodi development gates.
2. Verify the affected Shield/provider behavior and timing, including Back/Home/repeated navigation.
3. Obtain the current production approval before main/Pages publication. Preserve published 1.5.0 artifacts.

---
# Foundry skin 1.5.0 development handoff

Updated 2026-11-09 UTC. Branch: dev. Uncommitted product work: none. Candidate is validated for development review and remains unpublished. This documentation receipt follows runtime pin 579e84b3fed7e765bc7a0ec3ce30657a979c82af; do not repin the distribution merely for this receipt.

## Completed

- Thirteen approved Movies submenu PNGs retain exact generated bytes, approved SHA-256/byte counts and 1672x941 dimensions. media/foundry-movie-submenus/SOURCE.json retains provenance.
- Includes_FoundryMovieSubmenus.xml routes exact focused-folder/current-directory Movies labels. Helper 1.3.1's source-owned catalog Window property supplies verified context through paging, Back and playback reinitialization.
- Custom paths and selected-title fanart keep precedence. Unknown, similar, TV, mixed, nonmedia and unrelated contexts reject fallback routing. Explicit TV Shows/TV/Television folder/category names also reject untyped native directories despite cached Home Movies selection.
- Games view58, MyGames/include registration, installed-addon Home route/native fallback and recent/favorite rows are restored. Row order 17200/17300/17400 preserves the visibility contract. Existing Home geometry/navigation and unrelated artwork are preserved.
- Skin 1.5.0 requires helper 1.3.1. Published 1.4.0 bytes/pins/snapshots remain unchanged.

## Verification

[Distribution run 42564799165](https://github.com/3thirty3gitter/foundry-kodi-dist/actions/runs/42564799165), code bcd5875b4215bf6e268f05444c096b1a7f0a30ff, passed both 653-test suites, deterministic extracted rebuilding and all five native Kodi 21.3 gates. CI source/extracted skips: 0/1; local Windows: 1/2.

Native evidence covers all thirteen approved routes plus unknown/TV/mixed/custom/selected-fanart cases, pixel comparisons and source hashes, paging/rehydration, actual splash, interface/playback, Weather, and all eleven Games cases/twenty-five assertions. Jimmy independently inspected the complete artifact and ran the publication evidence validator read-only. Runtime skin inputs remained unchanged by the Games harness.

The approved PNG integrity check and all 92 published 1.4.0 artifact hashes passed. Only exact pre-existing Timer/PosterFlow warnings, proven by published-file/hash/input equality, are classified as baseline; new expressions fail.

Authoritative integration details and artifact SHA-256: sibling foundry-kodi-dist/docs/handoffs/LATEST.md and 2026-11-09-validation.json. Use the distribution's pinned source materialization for reproduction; this newer documentation tip is not the runtime pin.

## Next steps

1. Review the three dev branches and authorize draft PR creation if desired. Automatic approval review rejected posting PRs without explicit authorization; none were opened.
2. Validate actual Shield/provider behavior, arbitrary untyped provider contexts, performance, gameplay/controllers, sound and restart. Native Linux fixtures do not establish those results.
3. Capture the original affected-device playback-stop traceback; that separate issue remains unconfirmed.
4. Obtain current production approval before any main merge/publication through the existing updater. Close only this tab's own lease at actual session end.
