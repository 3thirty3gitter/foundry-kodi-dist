# Foundry for Kodi

Foundry 1.1.3 is the 3Thirty3 Kodi skin based on Nimbus 0.1.43 by Ivar Brandt.
Requires Kodi 21 Omega or newer and Foundry Helper 1.1.1.
Foundry Build 1.2.3 installs the standard add-ons together, including CocoScrapers, SlyGuy Trailers, TMDb metadata tools, Android TV UI Sounds and adaptive playback support.
Message dialogs use a translucent dark card with a soft shadow, theme accent and readable text, including the first skin confirmation before Home initializes its settings.
The sidebar reserves separate space for its logo, action buttons and menu. All 14 original 4K Foundry wallpapers are restored unchanged in the Foundry Wallpapers image resource, installed automatically with the skin. The selected category renders full-screen in both home layouts, including with background blur enabled. Widget artwork takes over only when entering a widget; returning to the sidebar restores the category wallpaper.

Add this source in Kodi File Manager:

https://3thirty3gitter.github.io/foundry-kodi-dist/

Install the repository ZIP, then select **Install from repository > Foundry Repository > Program add-ons > Foundry Build**.
Kodi resolves the skin and helper dependencies. Run Foundry Build to activate the skin.
The skin can also be selected directly under **Look and feel > Skin > Foundry**.

Release packages and checksums are maintained in `3thirty3gitter/foundry-kodi-dist`.
Code is GPLv2; artwork is CC BY-SA 4.0. Original Nimbus attribution is retained in LICENSE.txt.


The video OSD ports StreamPilot’s compact VOD poster panel and unified live-TV card, including the original audio/resolution badges, five-second idle hide, Back-to-dismiss, and fixed 30-second seek controls. Layout and badge source: StreamPilot commit `9f746fc90af40128e5fcfba60056ada99770b796`. Native Kodi playback/audio/subtitle settings are accessible from the VOD settings button; source selection remains the responsibility of the video add-on.
