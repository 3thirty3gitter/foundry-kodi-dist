# Foundry for Kodi

Local unpublished candidate: **skin 1.1.7 / Helper 1.1.2 / Build 1.2.8**. Public release remains Build 1.2.7 / skin 1.1.6 pending approval for this batch.

## Candidate wallpaper and Home changes

All fourteen original 3840x2160 wallpapers remain byte-identical in Foundry Wallpapers 1.0.0. Widget mode uses fourteen separately approved complete images, copied unchanged at their generated resolution: 1672x941, Live TV 1672x940. These are not native 4K assets. One stable image control fits each complete frame without crop/stretch, retains its previous texture until the replacement is ready, and crossfades filename changes over 450 ms. Menu/widget focus alone does not restart the transition. Custom backgrounds and action artwork retain priority; a missing widget image falls back to the original. Repair patches and runtime title masks are removed.

Populated/loading Home widgets suppress the focus-driven full-screen fanart and Flix detail panel on first and return entry. The native widget tree, coordinates, focus actions and selected item remain unchanged. Full library navigation is separate.

## StreamPilot VOD catalog

Native view 57 follows StreamPilot commit `a079c6a1c9c68a7217bbf0273fc532c39989dfa8`, `VodCatalogScreen.kt`, and the [actual Movies Trending reference](https://streampilot.ca/images/streampilot-movies-trending.webp), blob `a4c2d396eb3602846e537369db634638112e5f5a`. Component geometry is normalized to Kodi 1920x1080 against that 1672x941 reference, using a 240x360 poster anchor with 32px spacing; Android dp are not copied as Kodi pixels.

The view supplies cinematic fanart/shade; Back, title, breadcrumb and Search; clearlogo/title and native metadata; a separate ratings row; 2:3 posters, artwork-color glow, 1.19 focus scale and protected overflow; studio logo above the rail; and Page / Sort By below it. Roboto and its license are included. Existing text autoscroll preference is respected. There is no active global reduced-motion preference in the existing skin; wallpaper transitions contain no slide/zoom animation.

Kodi retains playable items, folders, selection, context menus and detail-return restoration. Up from the header opens native library options; Back/Right returns to the catalog. Paging selects the first item in the next/previous group of six; provider-owned next-page folders remain native items. Sort By opens Kodi's supported sort methods. Existing provider search is retained. These differ from StreamPilot's TMDB server pages, four-option sort and separate 32/68 search UI. Studio/clearlogo availability depends on Kodi/provider metadata or an optional installed studio-logo resource; missing artwork is not fabricated.

XML, geometry and mocked tests do not establish pixel-identical device rendering. Kodi 21 / Shield validation of first/return focus, paging, glow, loading/empty states, source selection and playback is still required before claiming equivalence.

## Optional OMDb / IMDb ratings

Open Skin settings > Extras > OMDb / IMDb ratings settings, or Foundry Helper settings. The provider is disabled and its key blank by default. A user can enter their own OMDb key and explicitly enable it. No key is shipped or configured. Kodi masks the key on screen but stores profile settings unencrypted; this is not Android Keystore security.

IMDb ratings are fetched through OMDb; Rotten Tomatoes/Metacritic are optional. Native Kodi IMDb values remain a fallback. Missing/N/A values are omitted. Lookup prefers IMDb ID, otherwise title/year/type; updates debounce 200 ms. Cache TTL is seven days, bounded stale use thirty days, misses fifteen minutes, and disk cache at most 2000 entries. Global quota/auth/offline backoff persists across titles/restarts. Key change/removal invalidates cache and in-flight responses, including while browsing is paused. HTTP timeouts are bounded; errors do not log keys or request URLs.

[OMDb documentation](https://www.omdbapi.com/) specifies CC BY-NC 4.0 content terms and non-affiliation with IMDb; its [free key page](https://www.omdbapi.com/apikey.aspx) lists 1000 requests/day. Confirm suitable usage rights before activation, particularly for commercial use. No provider data is redistributed. The [official IMDb GraphQL API](https://data.imdb.com/documentation/api-documentation/) is separately licensed through AWS Data Exchange and is not implemented, purchased or activated here. Existing TMDB/Kodi metadata provide artwork/descriptions when OMDb is unavailable.

## Earlier release notes

Foundry 1.1.3 is the 3Thirty3 Kodi skin based on Nimbus 0.1.43 by Ivar Brandt.
Requires Kodi 21 Omega or newer and Foundry Helper 1.1.1.
Foundry Build 1.2.3 installs the standard add-ons together, including CocoScrapers, SlyGuy Trailers, TMDb metadata tools, Android TV UI Sounds and adaptive playback support.
Message dialogs use a translucent dark card with a soft shadow, theme accent and readable text, including the first skin confirmation before Home initializes its settings.
The sidebar reserves separate space for its logo, action buttons and menu. All 14 original 4K Foundry wallpapers are restored unchanged in the Foundry Wallpapers image resource, installed automatically with the skin. The selected category renders full-screen in both home layouts, including with background blur enabled. Widget artwork takes over only when entering a widget; returning to the sidebar restores the category wallpaper.

Add this source in Kodi File Manager:

https://3thirty3gitter.github.io/foundry-kodi-dist/

Install the repository ZIP, then select **Install from repository > Foundry Repository > Program add-ons > Foundry Build**.
Kodi resolves the skin and helper dependencies. Run Foundry Build to activate the skin.
The skin can also be selected directly under **Look and feel > Skin > Foundry**.

Release packages and checksums are maintained in `3thirty3gitter/foundry-kodi-dist`.
Code is GPLv2; artwork is CC BY-SA 4.0. Original Nimbus attribution is retained in LICENSE.txt.


The video OSD ports StreamPilot’s compact VOD poster panel and unified live-TV card, including the original audio/resolution badges, five-second idle hide, Back-to-dismiss, and fixed 30-second seek controls. Layout and badge source: StreamPilot commit `9f746fc90af40128e5fcfba60056ada99770b796`. Native Kodi playback/audio/subtitle settings are accessible from the VOD settings button; source selection remains the responsibility of the video add-on.
