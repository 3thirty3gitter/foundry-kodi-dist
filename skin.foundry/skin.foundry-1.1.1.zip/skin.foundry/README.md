# Foundry for Kodi

Foundry 1.1.1 is the 3Thirty3 Kodi skin based on Nimbus 0.1.43 by Ivar Brandt.
Requires Kodi 21 Omega or newer and Foundry Helper 1.1.0.
Foundry Build 1.2.1 installs the standard add-ons together, including CocoScrapers, SlyGuy Trailers, TMDb metadata tools, Android TV UI Sounds and adaptive playback support.
Message dialogs use a translucent dark card with a soft shadow, theme accent and readable text, including the first skin confirmation before Home initializes its settings.
The sidebar reserves separate space for its logo, action buttons and menu. Category backgrounds follow menu focus; widget artwork takes over when entering a widget.

Add this source in Kodi File Manager:

https://3thirty3gitter.github.io/foundry-kodi-dist/

Install the repository ZIP, then select **Install from repository > Foundry Repository > Program add-ons > Foundry Build**.
Kodi resolves the skin and helper dependencies. Run Foundry Build to activate the skin.
The skin can also be selected directly under **Look and feel > Skin > Foundry**.

Release packages and checksums are maintained in `3thirty3gitter/foundry-kodi-dist`.
Code is GPLv2; artwork is CC BY-SA 4.0. Original Nimbus attribution is retained in LICENSE.txt.
