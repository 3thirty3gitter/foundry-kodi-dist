# Foundry for Kodi

Foundry 0.2.0 is the 3Thirty3 Kodi skin based on Nimbus 0.1.43 by Ivar Brandt.
Requires Kodi 21 Omega or newer and Foundry Helper 1.0.1.

Add this source in Kodi File Manager:

https://3thirty3gitter.github.io/foundry-kodi-dist/

Install the repository ZIP, then select **Install from repository > Foundry Repository > Program add-ons > Foundry Build**.
Kodi resolves the skin and helper dependencies. Run Foundry Build to activate the skin.
The skin can also be selected directly under **Look and feel > Skin > Foundry**.

Release packages and checksums are maintained in `3thirty3gitter/foundry-kodi-dist`.
Code is GPLv2; artwork is CC BY-SA 4.0. Original Nimbus attribution is retained in LICENSE.txt.
